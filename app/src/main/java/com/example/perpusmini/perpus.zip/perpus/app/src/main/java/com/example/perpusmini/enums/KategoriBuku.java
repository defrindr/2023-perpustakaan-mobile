package com.example.perpusmini.enums;

public enum KategoriBuku {
    MATEMATIKA,
    FIKSI,
    SEJARAH,
    SAINS,
    FILSAFAT
}
