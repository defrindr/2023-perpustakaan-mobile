package com.example.perpusmini.enums;

public class CollectionHelper {
    public static String user = "User";
    public static String buku = "Book";
    public static String pinjam = "Pinjam";
}
