package com.example.perpusmini.enums;

public enum Role {
    PEMINJAM,
    ADMIN,
    GUEST
}
