package com.example.perpusmini.enums;

public enum StatusPinjam {
    MENUNGGU_PERSETUJUAN_PINJAM,
    DIPINJAM,
    DITOLAK,
    MENUNGGU_PERSETUJUAN_KEMBALI,
    DIKEMBALIKAN,
}
